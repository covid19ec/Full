# -*- coding: utf-8 -*-
"""
Created on Fri Jun  9 18:04:43 2023

@author: Raul
"""
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import pyspark.sql.types as T
#Connection
spark = (
SparkSession.builder.appName("Recipes ML model - Are you a dessert?")
.config("spark.driver.memory", "8g")
.getOrCreate()
)
#Load data
food = spark.read.csv(
"D:/Perfil/Documentos/PythonPractice/epi_r.csv", inferSchema=True, header=True
)
#Function to clean column names
def sanitize_column_name(name):
    answer = name
    for i, j in ((" ", "_"), ("-", "_"), ("/", "_"), ("&", "and")):
        answer.replace(i,j)
    return"".join(
        [
            char
            for char in answer
            if char.isalpha() or char.isdigit() or char == "_"
        ]
    )
#Use to clean
food = food.toDF(*[sanitize_column_name(name) for name in food.columns])
#Remove outliers
food = food.where(
    (
     F.col("cakeweek").isin([0.0,1.0]) |
     F.col("cakeweek").isNull()
     ) &
    (
     F.col("wasteless").isin([0.0,1.0]) |
     F.col("wasteless").isNull()
     )
    )
#Check dim
print(food.count(),len(food.columns))
#Creating columns
IDENTIFIERS = ["title"]
CONTINUOUS_COLUMNS = ["rating","calories","protein","fat","sodium",]
TARGET_COLUMN = ["dessert"]
BINARY_COLUMNS = [
    x
    for x in food.columns
    if x not in IDENTIFIERS
    and x not in CONTINUOUS_COLUMNS
    and x not in TARGET_COLUMN
    ]
#Remove NA
food = food.dropna(
    how="all",
    subset=[x for x in food.columns if x not in IDENTIFIERS]
    )
food = food.dropna(subset=TARGET_COLUMN)
print(food.count(),len(food.columns))
#Set default NA value
food = food.fillna(0.0,subset=BINARY_COLUMNS)
#Remove step 1
food = food.where(F.trim(F.col('rating'))!='Cucumber')
#Transform
for column in ["rating","calories"]:
    #food = food.where(is_a_number(F.col(column)))
    food = food.withColumn(column,F.col(column).cast(T.DoubleType()))
#Remove outliers
#Cap values to 99% percentile
maximum = {
    "calories": 3203.0,
    "protein": 173.0,
    "fat": 207.0,
    "sodium": 5661.0
    }
#Loop
for k,v in maximum.items():
    food = food.withColumn(k,
                           F.when(F.isnull(F.col(k)), F.col(k)).otherwise(
                               F.least(F.col(k),F.lit(v)))
                           )

#Remove constant variables
inst_sum_of_binary_columns = [
    F.sum(F.col(x)).alias(x) for x in BINARY_COLUMNS
    ]
sum_of_binary_columns = (
    food.select(*inst_sum_of_binary_columns).head().asDict()
    )
#Identify columns to drop
num_rows = food.count()
too_rare_features = [
    k
    for k,v in sum_of_binary_columns.items() 
    if v<10 or v>(num_rows-10)
    ]
len(too_rare_features)
print(too_rare_features)
#Remove vars
BINARY_COLUMNS = list(set(BINARY_COLUMNS)-set(too_rare_features))
#Creation of new features
food = food.withColumn(
    "protein_ratio", F.col('protein')*4/F.col('calories')
    ).withColumn("fat_ratio",F.col('fat')*9/F.col('calories'))
#Fill null in new variables
food = food.fillna(0.0,subset=["protein_ratio","fat_ratio"])
#Update vector of variables
CONTINUOUS_COLUMNS += ["protein_ratio","fat_ratio"]
#Compute correlation
from pyspark.ml.feature import VectorAssembler
#Transformers and estimators for imputation
from pyspark.ml.feature import Imputer
OLD_COLS = ['calories','protein','fat','sodium']
NEW_COLS = ['calories_i','protein_i','fat_i','sodium_i']
#Imputer
imputer = Imputer(
    strategy="mean",
    inputCols=OLD_COLS,
    outputCols=NEW_COLS
    )
#Assign
imputer_model = imputer.fit(food)
CONTINUOUS_COLUMNS = list(set(CONTINUOUS_COLUMNS)-set(OLD_COLS))+NEW_COLS
#Checking for imputation
food_imputed = imputer_model.transform(food)
food_imputed.where("calories is null").select('calories','calories_i').show(5,False)
#Min max method
from pyspark.ml.feature import MinMaxScaler
CONTINUOUS_NB = [x for x in CONTINUOUS_COLUMNS if 'ratio' not in x]
continuous_assembler = VectorAssembler(
    inputCols=CONTINUOUS_NB,outputCol='continuous')
food_features = continuous_assembler.transform(food_imputed)
#Build imputer
continuous_scaler = MinMaxScaler(inputCol='continuous',outputCol='continuous_scaled')
food_features = continuous_scaler.fit(food_features).transform(food_features)
#Build a ML pipeline
#Pipeline
from pyspark.ml import Pipeline
import pyspark.ml.feature as MF
#Imputer
imputer = MF.Imputer(
    strategy='mean',
    inputCols=["calories", "protein", "fat", "sodium"],
    outputCols=["calories_i", "protein_i", "fat_i", "sodium_i"])
#Max min scaler
continuous_assembler = MF.VectorAssembler(
    inputCols=["rating", "calories_i", "protein_i", "fat_i", "sodium_i"],
    outputCol='continuous')
continuous_scaler = MF.MinMaxScaler(
    inputCol='continuous',
    outputCol='continuous_scaled')
#Build a vector of all features
preml_assembler = MF.VectorAssembler(
    inputCols=BINARY_COLUMNS+['continuous_scaled']+['protein_ratio','fat_ratio'],
    outputCol='features'
    )

#Logit
from pyspark.ml.classification import LogisticRegression
lr = LogisticRegression(
    featuresCol='features',
    labelCol='dessert',
    predictionCol='prediction'
    )
#Elements to add
scalar_na_filler = ScalarNAFiller(
    inputCols=BINARY_COLUMNS, outputCols=BINARY_COLUMNS, filler=0.0
    )
extreme_value_capper_cal = ExtremeValueCapper(
    inputCol="calories", outputCol="calories", boundary=2.0
    )
extreme_value_capper_pro = ExtremeValueCapper(
    inputCol="protein", outputCol="protein", boundary=2.0
    )
extreme_value_capper_fat = ExtremeValueCapper(
    inputCol="fat", outputCol="fat", boundary=2.0
    )
extreme_value_capper_sod = ExtremeValueCapper(
    inputCol="sodium", outputCol="sodium", boundary=2.0
    )
#Pipeline
from pyspark.ml.pipeline import Pipeline
food_pipeline = Pipeline(
    stages=[
        scalar_na_filler,
        extreme_value_capper_cal,
        extreme_value_capper_pro,
        extreme_value_capper_fat,
        extreme_value_capper_sod,
        imputer,
        continuous_assembler,
        continuous_scaler,
        preml_assembler,
        lr,
        ]
    )
#Model
from pyspark.ml.evaluation import BinaryClassificationEvaluator
train, test = food.randomSplit([0.7, 0.3], 13)
food_pipeline_model = food_pipeline.fit(train)
results = food_pipeline_model.transform(test)
#Evaluate
evaluator = BinaryClassificationEvaluator(
labelCol="dessert",
rawPredictionCol="rawPrediction",
metricName="areaUnderROC",
)
accuracy = evaluator.evaluate(results)
print(f"Area under ROC = {accuracy} ")
#Export
food_pipeline_model.save("D:/Perfil/Documentos/PythonPractice/food_pipeline.model")
